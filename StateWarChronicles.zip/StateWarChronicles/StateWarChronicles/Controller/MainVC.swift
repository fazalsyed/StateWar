//
//  MainVC.swift
//  StateWarChronicles
//
//  Created by syed fazal abbas on 20/10/23.
//

import UIKit
import MessageUI

class MainVC: UIViewController {
    
    @IBOutlet var tblPalace: UITableView!
    var arrSideMenu = [Sidemenu(img_SideMenu: "ic_Share", lbl_SideMenu: "Battle"),Sidemenu(img_SideMenu: "ic_Share", lbl_SideMenu: "Share it"),Sidemenu(img_SideMenu: "ic_RateUs", lbl_SideMenu: "Rate Us"),Sidemenu(img_SideMenu: "ic_Privacy", lbl_SideMenu: "Privacy Policy"),Sidemenu(img_SideMenu: "ic_ContactUS", lbl_SideMenu: "Contact Us"),Sidemenu(img_SideMenu: "ic_AboutApp", lbl_SideMenu: "Quiz"),Sidemenu(img_SideMenu: "ic_AboutApp", lbl_SideMenu: "About App")]
    override func viewDidLoad() {
        super.viewDidLoad()
        tblPalace.delegate = self
        tblPalace.dataSource = self
        xibLoad()
    }
    
    func xibLoad() {
        tblPalace.register(UINib(nibName: "CellT_SideMenu", bundle: nil), forCellReuseIdentifier: "CellT_SideMenu")
    }
}
//Mark : UITableViewDelegate & UiTableViewDataSource.
extension MainVC : UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrSideMenu.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.row == 0{
            let cell = tableView.dequeueReusableCell(withIdentifier: "CellT_SideMenu") as! CellT_SideMenu
            cell.lbl_SideMenu.text = arrSideMenu[indexPath.row].lbl_SideMenu
            let selectedView = UIView()
            selectedView.backgroundColor = UIColor.clear
            cell.selectedBackgroundView = selectedView
            return cell
        }
        if indexPath.row == 1{
            let cell = tableView.dequeueReusableCell(withIdentifier: "CellT_SideMenu") as! CellT_SideMenu
            cell.lbl_SideMenu.text = arrSideMenu[indexPath.row].lbl_SideMenu
            let selectedView = UIView()
            selectedView.backgroundColor = UIColor.clear
            cell.selectedBackgroundView = selectedView
            return cell
        }
        else if indexPath.row == 2{
            let cell = tableView.dequeueReusableCell(withIdentifier: "CellT_SideMenu") as! CellT_SideMenu
            cell.lbl_SideMenu.text = arrSideMenu[indexPath.row].lbl_SideMenu
            let selectedView = UIView()
            selectedView.backgroundColor = UIColor.clear
            cell.selectedBackgroundView = selectedView
            return cell
        }
        else if indexPath.row == 3{
            let cell = tableView.dequeueReusableCell(withIdentifier: "CellT_SideMenu") as! CellT_SideMenu
            cell.lbl_SideMenu.text = arrSideMenu[indexPath.row].lbl_SideMenu
            let selectedView = UIView()
            selectedView.backgroundColor = UIColor.clear
            cell.selectedBackgroundView = selectedView
            return cell
        }
        else if indexPath.row == 4{
            let cell = tableView.dequeueReusableCell(withIdentifier: "CellT_SideMenu") as! CellT_SideMenu
            cell.lbl_SideMenu.text = arrSideMenu[indexPath.row].lbl_SideMenu
            let selectedView = UIView()
            selectedView.backgroundColor = UIColor.clear
            cell.selectedBackgroundView = selectedView
            return cell
        }
        else if indexPath.row == 5{
            let cell = tableView.dequeueReusableCell(withIdentifier: "CellT_SideMenu") as! CellT_SideMenu
            cell.lbl_SideMenu.text = arrSideMenu[indexPath.row].lbl_SideMenu
            let selectedView = UIView()
            selectedView.backgroundColor = UIColor.clear
            cell.selectedBackgroundView = selectedView
            return cell
        }
        else if indexPath.row == 6{
            let cell = tableView.dequeueReusableCell(withIdentifier: "CellT_SideMenu") as! CellT_SideMenu
            cell.lbl_SideMenu.text = arrSideMenu[indexPath.row].lbl_SideMenu
            let selectedView = UIView()
            selectedView.backgroundColor = UIColor.clear
            cell.selectedBackgroundView = selectedView
            return cell
        }
        return UITableViewCell()
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 70
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.row == 0{
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "BattlePlace") as? BattlePlace
            self.navigationController?.pushViewController(vc!, animated: true)
        }
        if indexPath.row == 1{
            let objectsToShare = "Download \(Constant.AppName) and Share \(Constant.AppName) to your Friends" as Any
            if let name = NSURL(string: "\(Constant.appUrl)") {
                let activityVC = UIActivityViewController(activityItems: ["\(objectsToShare) \n\n \(name)"], applicationActivities: nil)
                activityVC.setValue(Constant.AppName, forKey: "subject")
                if UIDevice.current.userInterfaceIdiom == .pad {
                    activityVC.popoverPresentationController?.sourceView = self.view
                    //                    activityVC.popoverPresentationController?.sourceRect = sender.frame
                }
                self.present(activityVC, animated: true, completion: nil)
            }
        }
        else if indexPath.row == 2{
            guard let url = URL(string: Constant.ReviewURl) else { return }
            UIApplication.shared.open(url)
        }else if indexPath.row == 3 {
            guard let url = URL(string: Constant.url_Terms) else { return }
            UIApplication.shared.open(url)
        }
        else  if indexPath.row == 4{
            // Check if the device can send email
            if MFMailComposeViewController.canSendMail() {
                let mailComposeVC = MFMailComposeViewController()
                mailComposeVC.mailComposeDelegate = self
                mailComposeVC.setToRecipients(["support@example.com"]) // Set the recipient email address
                mailComposeVC.setSubject("Regarding Your App") // Set the email subject
                
                // You can pre-fill the email body with user-specific details if needed
                let userEmailAddress = "user@example.com"
                let emailBody = "Dear support team,\n\nI am writing to you from my app with the email address \(userEmailAddress)."
                
                mailComposeVC.setMessageBody(emailBody, isHTML: false)
                
                // Present the email composer
                present(mailComposeVC, animated: true, completion: nil)
            } else {
                // Handle the case where the device can't send email (e.g., show an alert)
                let alertController = UIAlertController(
                    title: "Email Not Configured",
                    message: "Your device is not configured to send email.",
                    preferredStyle: .alert
                )
                let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
                alertController.addAction(okAction)
                present(alertController, animated: true, completion: nil)
            }
        }
        else if indexPath.row == 5 {
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "PlayVC1") as? PlayVC1
            self.navigationController?.pushViewController(vc!, animated: true)
        }
        else if indexPath.row == 6 {
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "AboutApp") as? AboutApp
            self.navigationController?.pushViewController(vc!, animated: true)
        }
    }
}
//Mark : Delegate Used for Mail.
extension MainVC : MFMailComposeViewControllerDelegate{
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
        controller.dismiss(animated: true, completion: nil)
    }
}
//extension MainVC: UITableViewDelegate, UITableViewDataSource {
//    
//    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        return battleSections.count
//    }
//    
//    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//        let cell = tblPalace.dequeueReusableCell(withIdentifier: "CellT_ManiVC", for: indexPath) as! CellT_ManiVC
//        cell.mylbl.text = battleSections[indexPath.row]
//        let selectedView = UIView()
//        selectedView.backgroundColor = UIColor.clear
//        cell.selectedBackgroundView = selectedView
//        return cell
//    }
//    
//    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
//        return 200
//    }
//    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//            let selectedPalace =           DataModel.battleAreas[indexPath.section].battles[indexPath.row]
//            let vc = self.storyboard?.instantiateViewController(withIdentifier: "BattlePlace") as? BattlePlace
//            vc?.selectedPalace = selectedPalace
//            self.navigationController?.pushViewController(vc!, animated: true)
//            
//    }
//}

