//
//  DetailBattleVC.swift
//  StateWarChronicles
//
//  Created by syed fazal abbas on 20/10/23.
//

import UIKit

class DetailBattleVC: UIViewController {
    
    var ArrDes = DataModel.battleAreas
    @IBOutlet var tblDetail: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        tblDetail.delegate = self
        tblDetail.dataSource = self
        xibLoad()
    }

    // Marks: Func to Load Xib
    func xibLoad() {
        tblDetail.register(UINib(nibName: "CellT_BattleDetails", bundle: nil), forCellReuseIdentifier: "CellT_BattleDetails")
        tblDetail.register(UINib(nibName: "Header2", bundle: nil), forHeaderFooterViewReuseIdentifier: "Header2")
    }
}

// Marks: UITableViewDelegate & UITableViewDataSource
// Marks: UITableViewDelegate & UITableViewDataSource
extension DetailBattleVC: UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return ArrDes.count // Assuming ArrDes represents sections
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return ArrDes[section].battles.count // Return the number of battles in the current section
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tblDetail.dequeueReusableCell(withIdentifier: "CellT_BattleDetails", for: indexPath) as! CellT_BattleDetails
        let battleDescription = ArrDes[indexPath.section].battles[indexPath.row].battleDescription
        cell.mylbl.text = battleDescription
        return cell
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 60
    }
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
            let headerView = tableView.dequeueReusableHeaderFooterView(withIdentifier: "Header2") as! Header2
            headerView.mylbl.text = ArrDes[section].areaName
            return headerView
    }
}

