//
//  BattlePlace.swift
//  StateWarChronicles
//
//  Created by syed fazal abbas on 09/10/23.
//

import UIKit

class BattlePlace: UIViewController {
    
    var selectedPalace: Battle?
    @IBOutlet var tblPalace: UITableView!
    @IBOutlet var sideBarView: UIView!
    @IBOutlet var containerView: UIView!
    let screenHeight = UIScreen.main.bounds.height
    
    // Define an array of BattleArea
    var battleSections = DataModel.battleAreas
    var isleftSideMenuOpen = false
    var isSectionExpanded: [Bool] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tblPalace.delegate = self
        tblPalace.dataSource = self
        isSectionExpanded = Array(repeating: false, count: battleSections.count)
        xibLoad()
    }
    
    func xibLoad() {
        tblPalace.register(UINib(nibName: "CellT_Palace", bundle: nil), forCellReuseIdentifier: "CellT_Palace")
        tblPalace.register(UINib(nibName: "Header2", bundle: nil), forHeaderFooterViewReuseIdentifier: "Header2")
    }
}

extension BattlePlace: UITableViewDelegate, UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return battleSections.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // Return the number of battles in the section if it's expanded, 0 if it's collapsed
        return isSectionExpanded[section] ? battleSections[section].battles.count : 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tblPalace.dequeueReusableCell(withIdentifier: "CellT_Palace", for: indexPath) as! CellT_Palace
        let selectedView = UIView()
        selectedView.backgroundColor = UIColor.clear // Replace 'blue' with your desired color
        cell.selectedBackgroundView = selectedView
        if isSectionExpanded[indexPath.section] {
            let battle = battleSections[indexPath.section].battles[indexPath.row]
            cell.lbl_Location.text = "Battle Name: " + battle.battleName
            cell.lbl_Timing.text = "Battle Date: " + battle.battleDate
            cell.lbl_About.text = "Click To Know About Battle"
        } else {
            cell.lbl_Location.text = ""
            cell.lbl_Timing.text = ""
            cell.lbl_About.text = ""
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return isSectionExpanded[indexPath.section] ? 150 : 0
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let cell = tblPalace.dequeueReusableHeaderFooterView(withIdentifier: "Header2") as! Header2
        cell.mylbl.text = battleSections[section].areaName
        
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(headerTapped(_:)))
        cell.addGestureRecognizer(tapGesture)
        cell.tag = section
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 80
    }
    
    @objc func headerTapped(_ sender: UITapGestureRecognizer) {
        guard let section = sender.view?.tag else {
            return
        }

        // Check if the last header is clicked
        if section == battleSections.count - 1 {
            // Present the quiz view controller
            presentQuizViewController()
        } else {
            for (index, _) in isSectionExpanded.enumerated() {
                if index != section {
                    isSectionExpanded[index] = false
                }
            }
            isSectionExpanded[section].toggle()
            tblPalace.reloadSections(IndexSet(integersIn: 0..<isSectionExpanded.count), with: .automatic)
        }
    }
    func presentQuizViewController() {
        let quizVC = self.storyboard?.instantiateViewController(withIdentifier: "PlayVC1") as? PlayVC1
        self.navigationController?.pushViewController(quizVC!, animated: true)
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
            let selectedPalace =           DataModel.battleAreas[indexPath.section].battles[indexPath.row]
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "BattleHerosDetail") as? BattleHerosDetail
            vc?.selectedPalace = selectedPalace
            self.navigationController?.pushViewController(vc!, animated: true)
            
    }
}
