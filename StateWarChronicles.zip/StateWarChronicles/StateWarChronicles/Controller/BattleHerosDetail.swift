//
//  BattleHerosDetail.swift
//  StateWarChronicles
//
//  Created by syed fazal abbas on 20/10/23.
//

import UIKit

class BattleHerosDetail: UIViewController {
    
    var selectedPalace: Battle?
    @IBOutlet var colBattleVillan: UICollectionView!
    @IBOutlet var colBattleHero: UICollectionView!
    override func viewDidLoad() {
        super.viewDidLoad()
        colBattleHero.delegate = self
        colBattleHero.dataSource = self
        colBattleVillan.delegate = self
        colBattleVillan.dataSource = self
        LoadXib()
    }
    //Marks : Func to Load Xib()
    func LoadXib(){
        colBattleHero.register(UINib(nibName: "CellT_BattleHero", bundle: nil), forCellWithReuseIdentifier: "CellT_BattleHero")
    }
    
    @IBAction func btnTappedToSeeBattle(_ sender: UIButton) {
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "DetailBattleVC") as? DetailBattleVC
            self.navigationController?.pushViewController(vc!, animated: true)
        }
}
    //Marks : UICollectionViewDelegate & UICollectionViewDataSource
    extension BattleHerosDetail : UICollectionViewDelegate,UICollectionViewDataSource{
        func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
            if collectionView == colBattleHero{
                return selectedPalace?.battleHero.count ?? 0
            }
            else if collectionView == colBattleVillan{
                return selectedPalace?.battleVillan.count ?? 0
            }
            return 0
        }
        
        func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
            let cell = colBattleHero.dequeueReusableCell(withReuseIdentifier: "CellT_BattleHero", for: indexPath) as! CellT_BattleHero
            if collectionView == colBattleHero {
                if let imageName = selectedPalace?.battleHeroImg[indexPath.row], let image = UIImage(named: imageName) {
                    cell.img_battleHero.image = image
                }
                cell.lbl_BattleHero.text = selectedPalace?.battleHero[indexPath.row]
                return cell
            } else if collectionView == colBattleVillan {
                if let imageName = selectedPalace?.battleVillanImg[indexPath.row], let image = UIImage(named: imageName) {
                    cell.img_battleHero.image = image
                }
                cell.lbl_BattleHero.text = selectedPalace?.battleHero[indexPath.row]
                return cell
            }
            
            return UICollectionViewCell()
        }
    }
    //Marks : UICollectionViewDelegateFlowLayout
    extension BattleHerosDetail : UICollectionViewDelegateFlowLayout{
        func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
            let size = colBattleHero.frame.width
            let Height : CGFloat = 180
            return CGSize(width: size/2, height: Height)
        }
        func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
            return 0
        }
        func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
            return 0
        }
    }
