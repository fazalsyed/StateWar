//
//  CellT_SideMenu.swift
//  StateWarChronicles
//
//  Created by syed fazal abbas on 09/10/23.
//

import UIKit

class CellT_SideMenu: UITableViewCell {

    @IBOutlet var btn_SideMenu: UIButton!
    @IBOutlet var lbl_SideMenu: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
