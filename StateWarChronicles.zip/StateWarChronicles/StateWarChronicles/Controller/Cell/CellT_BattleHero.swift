//
//  CellT_BattleHero.swift
//  StateWarChronicles
//
//  Created by syed fazal abbas on 20/10/23.
//

import UIKit

class CellT_BattleHero: UICollectionViewCell {

    @IBOutlet var lbl_BattleHero: UILabel!
    @IBOutlet var img_battleHero: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        MakeRoundImg()
    }
    func MakeRoundImg(){
        img_battleHero.layer.borderWidth = 1.0
        img_battleHero.layer.masksToBounds = false
        img_battleHero.layer.borderColor = UIColor.white.cgColor
        img_battleHero.layer.cornerRadius = img_battleHero.frame.size.height/2
        img_battleHero.clipsToBounds = true
    }

}
