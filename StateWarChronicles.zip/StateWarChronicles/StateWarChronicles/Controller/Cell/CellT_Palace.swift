//
//  CellT_Palace.swift
//  StateWarChronicles
//
//  Created by syed fazal abbas on 09/10/23.
//

import UIKit

class CellT_Palace: UITableViewCell {
    @IBOutlet var lbl_Location: UILabel!
    @IBOutlet var vwMain: UIView!
    @IBOutlet var lbl_About: UILabel!
    @IBOutlet var lbl_Timing: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
}
