//
//  Header2.swift
//  StateWarChronicles
//
//  Created by syed fazal abbas on 09/10/23.
//

import UIKit

class Header2: UITableViewHeaderFooterView {

    @IBOutlet var vwMain: UIView!
    @IBOutlet var mylbl: UILabel!
    
}

