//
//  BattleDetailVC.swift
//  StateWarChronicles
//
//  Created by syed fazal abbas on 09/10/23.
//

import UIKit

class BattleDetailVC: UIViewController {
    
    var selectedPalace: Battle?
    @IBOutlet var vw_ParkDetail: UITextView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        UiUpdate()
    }
    //Marks : UIUpdate()
    func UiUpdate(){
        vw_ParkDetail.layer.borderColor = UIColor.black.cgColor
        vw_ParkDetail.layer.borderWidth = 2
        if let palace = selectedPalace {
            vw_ParkDetail.text = palace.battleDescription
        }
    }
}
