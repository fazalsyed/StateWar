//
//  CellT_BattleDetails.swift
//  StateWarChronicles
//
//  Created by syed fazal abbas on 20/10/23.
//

import UIKit

class CellT_BattleDetails: UITableViewCell {

    @IBOutlet var mylbl: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
