//
//  LevelVC.swift
//   Food_Tech
//
//  Created by Fazal Abbas on 12/09/23.
//

import UIKit

class LevelVC: UIViewController {

    @IBOutlet weak var btn1: UIButton!
    @IBOutlet weak var btn2: UIButton!
    @IBOutlet weak var btn3: UIButton!
    @IBOutlet weak var btn4: UIButton!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

       let btn = [btn1,btn2,btn3,btn4]
        
        for btn in btn {
            btn?.layer.cornerRadius = 20
            btn?.layer.borderWidth = 1
            btn?.layer.borderColor = UIColor.black.cgColor
        }
        
    }
    
   
    @available(iOS 13.0, *)
    @IBAction func Buttontapped(_ sender: UIButton) {
        switch sender.tag {
            
            case 1:
                // Navigate to View Controller 1
               let vc = self.storyboard?.instantiateViewController(identifier: "PlayVC1") as? PlayVC1
                self.navigationController?.pushViewController(vc!, animated: true)
            
            case 2:
                // Navigate to View Controller 2
            let vc = self.storyboard?.instantiateViewController(identifier: "PlayVC2") as? PlayVC2
             self.navigationController?.pushViewController(vc!, animated: true)
    
            
            case 3:
                // Navigate to View Controller 3
            let vc = self.storyboard?.instantiateViewController(identifier: "PlayVC3") as? PlayVC3
             self.navigationController?.pushViewController(vc!, animated: true)
                
            case 4:
                // Navigate to View Controller 4
            let vc = self.storyboard?.instantiateViewController(identifier: "PlayVC4") as? PlayVC4
             self.navigationController?.pushViewController(vc!, animated: true)
            
            default:
                break
            }
    }
    
    
    
}

