//
//  Level2.swift
//   Food_Tech
//
//  Created by Fazal Abbas on 12/09/23.
//
import Foundation
class Level2 {
    var list = [Question]()
    
    init() {
        // Expert Difficulty Questions
        list.append(Question(questionText: "The Red Fort in Delhi was built by which Mughal Emperor?", choiceA: "Babur", choiceB: "Humayun", choiceC: "Akbar", choiceD: "Shah Jahan", answer: 4))

        list.append(Question(questionText: "Which city in Rajasthan is known as the 'Pink City'?", choiceA: "Jodhpur", choiceB: "Udaipur", choiceC: "Jaipur", choiceD: "Bikaner", answer: 3))

        list.append(Question(questionText: "Who was the first Chief Minister of Gujarat?", choiceA: "Sardar Patel", choiceB: "Morarji Desai", choiceC: "Vijay Rupani", choiceD: "Jawaharlal Nehru", answer: 2))

        list.append(Question(questionText: "Which state is famous for the Ajanta and Ellora Caves?", choiceA: "Karnataka", choiceB: "Madhya Pradesh", choiceC: "Maharashtra", choiceD: "Gujarat", answer: 3))

        list.append(Question(questionText: "The famous 'Jallianwala Bagh' massacre occurred in which city?", choiceA: "Amritsar", choiceB: "Kolkata", choiceC: "Delhi", choiceD: "Mumbai", answer: 1))
        
    }
}
