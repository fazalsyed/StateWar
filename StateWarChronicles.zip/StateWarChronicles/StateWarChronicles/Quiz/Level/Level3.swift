//
//  Level3.swift
//  Food_Tech
//
//  Created by Fazal Abbas on 12/09/23.
//

import Foundation
class Level3 {
    var list = [Question]()
    
    init() {
        
        // Medium Difficulty Questions
        list.append(Question(questionText: "Who was the first President of India?", choiceA: "Sardar Patel", choiceB: "Dr. Rajendra Prasad", choiceC: "Jawaharlal Nehru", choiceD: "Indira Gandhi", answer: 2))

        list.append(Question(questionText: "The 'Qutub Minar' in Delhi is a UNESCO World Heritage Site. Who built it?", choiceA: "Aurangzeb", choiceB: "Akbar", choiceC: "Qutb-ud-din Aibak", choiceD: "Humayun", answer: 3))

        list.append(Question(questionText: "In which state is the famous 'Dudhsagar Waterfall' located?", choiceA: "Goa", choiceB: "Kerala", choiceC: "Karnataka", choiceD: "Goa", answer: 1))

        list.append(Question(questionText: "What is the historical significance of the city of Fatehpur Sikri in Uttar Pradesh?", choiceA: "It was the capital of the Mughal Empire.", choiceB: "It's a UNESCO World Heritage Site.", choiceC: "It was the birthplace of Mahatma Gandhi.", choiceD: "It was a prominent Buddhist center.", answer: 1))

        list.append(Question(questionText: "The 'Agra Fort' in Uttar Pradesh is also known by another name. What is it?", choiceA: "Amber Fort", choiceB: "Fatehpur Sikri", choiceC: "Red Fort", choiceD: "Lal Qila", answer: 3))


    }
}
