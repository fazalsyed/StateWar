//
//  Level4.swift
//   Food_Tech
//
//  Created by Fazal Abbas on 12/09/23.
//
import Foundation
class Level4 {
    var list = [Question]()
    
    init() {

        // Hard Difficulty Questions
        list.append(Question(questionText: "Which state is famous for the 'City of Lakes' and the 'Lake Palace'?", choiceA: "Rajasthan", choiceB: "Uttar Pradesh", choiceC: "Madhya Pradesh", choiceD: "Rajasthan", answer: 1))

        list.append(Question(questionText: "The 'Victoria Memorial' is a famous monument in which Indian city?", choiceA: "Kolkata", choiceB: "Mumbai", choiceC: "Chennai", choiceD: "Kolkata", answer: 1))

        list.append(Question(questionText: "Who was the Maratha warrior king known for his guerilla warfare tactics?", choiceA: "Baji Rao I", choiceB: "Shivaji", choiceC: "Balaji Vishwanath", choiceD: "Balaji Baji Rao", answer: 2))

        list.append(Question(questionText: "In which state is the 'Hawa Mahal' located?", choiceA: "Rajasthan", choiceB: "Madhya Pradesh", choiceC: "Uttar Pradesh", choiceD: "Gujarat", answer: 1))

    }
}
