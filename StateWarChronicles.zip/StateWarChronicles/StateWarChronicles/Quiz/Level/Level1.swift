//
//  Level1.swift
//   Food_Tech
//
//  Created by Fazal Abbas on 12/09/23.
//
import Foundation
class Level1 {
    var list = [Question]()
    
    init() {
        
        // Easy Questions
        list.append(Question(questionText: "In which Indian state did the Battle of Panipat take place?", choiceA: "Gujarat", choiceB: "Maharashtra", choiceC: "Uttar Pradesh", choiceD: "Rajasthan", answer: 3))
        
        list.append(Question(questionText: "Who was the Mughal Emperor during the Battle of Haldighati in Rajasthan?", choiceA: "Akbar", choiceB: "Aurangzeb", choiceC: "Babur", choiceD: "Akbar", answer: 1))
        
        list.append(Question(questionText: "Which historical battle took place at Kurukshetra in Haryana?", choiceA: "Battle of Plassey", choiceB: "Battle of Saragarhi", choiceC: "Battle of Kurukshetra", choiceD: "Battle of Panipat", answer: 3))
        
        list.append(Question(questionText: "Who was the Maratha leader in the Battle of Sinhagad in Maharashtra?", choiceA: "Shivaji", choiceB: "Baji Rao I", choiceC: "Balaji Vishwanath", choiceD: "Shivaji", answer: 2))
        
        list.append(Question(questionText: "Which historical event led to the formation of the state of Uttarakhand?", choiceA: "Independence of India", choiceB: "Mumbai Attacks", choiceC: "Uttarakhand Floods", choiceD: "Uttarakhand Statehood Movement", answer: 4))
    }
}
