//
//  PlayVC2.swift
//   Food_Tech
//
//  Created by Fazal Abbas on 12/09/23.
//

import UIKit
import AVFoundation

class PlayVC2: UIViewController {
    
    @IBOutlet weak var numberLbl: UILabel!
    @IBOutlet weak var scoreLbl: UILabel!
    
    @IBOutlet weak var quesLbl: UILabel!
    
    var selectedLevel = "Quiz"
    
    var allQuestions = Level2()


    var questionNumber : Int = 0
    var score : Int = 0
    var number : Int = 1
    var selectedAnswer : Int = 0
    
    @IBOutlet weak var optionA: UIButton!
    @IBOutlet weak var optionB: UIButton!
    @IBOutlet weak var optionC: UIButton!
    @IBOutlet weak var optionD: UIButton!
    
    override func viewWillAppear(_ animated: Bool) {
        self.title = selectedLevel
        self.navigationController?.isNavigationBarHidden = false
        
        // BORDERS
        let arrayOfElements = [ quesLbl , optionA, optionB, optionC, optionD ]
        for element in arrayOfElements {
            element?.layer.cornerRadius = 20
            //element?.layer.borderColor = UIColor.black.cgColor
            //element?.layer.borderWidth = 5
        }
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        animateViews()
        
        setUpView()
        quesLbl.layer.cornerRadius = 20
        quesLbl.layer.shadowColor = UIColor.systemYellow.cgColor
        numberLbl.layer.cornerRadius = 20
       
        
        
        optionA.layer.cornerRadius = 20
        optionB.layer.cornerRadius = 20
        optionC.layer.cornerRadius = 20
        optionD.layer.cornerRadius = 20
        
        scoreLbl.layer.cornerRadius = 20
       
    }
   
    
    func setUpView(){
        updateUI()
        updateQuestion()
    }
    
    @IBAction func Button(_ sender: UIButton) {
        
        if sender.tag == selectedAnswer {
            score += 1
        }
        else{
            
        }
        
        questionNumber += 1
        updateQuestion()
        
    }
    
    func updateQuestion(){
        
        if questionNumber <= allQuestions.list.count - 1{
            
            quesLbl.text =  allQuestions.list[questionNumber].question
            
            optionA.setTitle(allQuestions.list[questionNumber].optionA, for:.normal)
            optionB.setTitle(allQuestions.list[questionNumber].optionB, for:.normal)
            optionC.setTitle(allQuestions.list[questionNumber].optionC, for:.normal)
            optionD.setTitle(allQuestions.list[questionNumber].optionD, for:.normal)
            
            selectedAnswer = allQuestions.list[questionNumber].correctAnswer
            updateUI()
            
        }else {
            let alert = UIAlertController(title: "Awesome", message: "End of Quiz. Do you want to start over?", preferredStyle: .alert)
            let restartAction = UIAlertAction(title: "Start Again??", style: .default, handler: {action in self.restartQuiz()})
            alert.addAction(restartAction)
            present(alert, animated: true, completion: nil)
        }
        
    }
    
    func updateUI(){
        scoreLbl.text = "Score: \(score)"
        numberLbl.text = "Question No - \(questionNumber + 1)"
    }
    
    func restartQuiz(){
        score = 0
        questionNumber = 0
        updateQuestion()
    }
    func animateViews() {
                animateView(view: numberLbl, direction: .fromLeft)
                animateView(view: numberLbl, direction: .fromLeft)
        animateView(view: quesLbl, direction: .fromRight)
        animateView(view: optionA, direction: .fromBottom)
        animateView(view: optionB, direction: .fromLeft)
        animateView(view: optionC, direction: .fromRight)
        animateView(view: optionD, direction: .fromTop)
            }
            
            func animateView(view: UIView, direction: AnimationDirection) {
                let animation = CATransition()
                animation.type = CATransitionType.push
                animation.subtype = direction.subtype
                animation.duration = 1.0
                view.layer.add(animation, forKey: nil)
            }
            

        enum AnimationDirection {
            case fromLeft
            case fromRight
            case fromTop
            case fromBottom
            
            var subtype: CATransitionSubtype {
                switch self {
                case .fromLeft:
                    return .fromLeft
                
                case .fromRight:
                    return .fromRight
                
                case .fromTop:
                    return .fromTop
                    
                case .fromBottom:
                    return . fromBottom
                }
            }
        }
}



