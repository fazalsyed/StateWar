//
//  Question.swift
//   Food_Tech
//
//  Created by Fazal Abbas on 12/09/23.
//
import Foundation
class Question{
    let question :String
    let optionA :String
    let optionB :String
    let optionC :String
    let optionD :String
    let correctAnswer :Int
    
    init(questionText:String,choiceA:String,choiceB:String,choiceC:String,choiceD:String,answer:Int){
        question = questionText
        optionA = choiceA
        optionB = choiceB
        optionC = choiceC
        optionD = choiceD
        correctAnswer = answer
    }
}
