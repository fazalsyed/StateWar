//
//  Constant.swift
//  StateWarChronicles
//
//  Created by syed fazal abbas on 09/10/23.
//

import Foundation

class Constant : NSObject{
    
    static let AppName = "StateWarChronicles"
    static let url_Terms = "https://www.privacypolicygenerator.info/live.php?token=8ilteYueyTxAi7nmoY9XZISBb33MNEsm"
    static let appId = "id64417cg3579692"
    static let appUrl = "https://apps.apple.com/app/\(appId)"
    static let ReviewURl = "itms-apps://itunes.apple.com/app/id/\(appId)?action=write-review"
    
}
