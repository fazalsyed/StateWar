//
//  Struct.swift
//  StateWarChronicles
//
//  Created by syed fazal abbas on 09/10/23.
//

import Foundation

struct Sidemenu{
    var img_SideMenu : String?
    var lbl_SideMenu : String?
}

struct Battle {
    let battleName: String
    let battleDate: String
    let battleDescription: String
    let battleHero : [String]
    let battleHeroImg : [String]
    let battleVillan : [String]
    let battleVillanImg : [String]
}

struct BattleArea {
    let areaName: String
    var battles: [Battle]
}
